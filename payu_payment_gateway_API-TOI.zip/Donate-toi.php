<?php

$MERCHANT_KEY = "hW7DBsKt";
$SALT = "lPPYFQFEou";
$veryfy=strtolower(hash('sha512', $SALT));
// Merchant Key and Salt as provided by Payu.

//$PAYU_BASE_URL = "https://sandboxsecure.payu.in";   // For Sandbox Mode
$PAYU_BASE_URL = "https://secure.payu.in";      // For Production Mode

$action = '';

$posted = array();
if(!empty($_POST)) {
    //print_r($_POST);
  foreach($_POST as $key => $value) {    
    $posted[$key] = $value; 
  
  }
}

$formError = 0;

if(empty($posted['txnid'])) {
  // Generate random transaction id
  $txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 20);
} else {
  $txnid = $posted['txnid'];
}
$hash = '';
// Hash Sequence
$hashSequence = "key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10";
if(empty($posted['hash']) && sizeof($posted) > 0) {
  if(
          empty($posted['key'])
          || empty($posted['txnid'])
          || empty($posted['amount'])
          || empty($posted['firstname'])
          || empty($posted['email'])
          || empty($posted['phone'])
          || empty($posted['productinfo'])
          || empty($posted['surl'])
          || empty($posted['furl'])
      || empty($posted['service_provider'])
  ) {
    $formError = 1;
  } else {
    //$posted['productinfo'] = json_encode(json_decode('[{"name":"tutionfee","description":"","value":"500","isRequired":"false"},{"name":"developmentfee","description":"monthly tution fee","value":"1500","isRequired":"false"}]'));
  $hashVarsSeq = explode('|', $hashSequence);
    $hash_string = '';  
  foreach($hashVarsSeq as $hash_var) {
      $hash_string .= isset($posted[$hash_var]) ? $posted[$hash_var] : '';
      $hash_string .= '|';
    }

    $hash_string .= $SALT;


    $hash = strtolower(hash('sha512', $hash_string));
    $m=$posted['phone'];
 
    $action = $PAYU_BASE_URL . '/_payment';
  }
} elseif(!empty($posted['hash'])) {
  $hash = $posted['hash'];
  $action = $PAYU_BASE_URL . '/_payment';
  
}
?>



<!DOCTYPE html>
<html>
<head>
  <script>
    var hash = '<?php echo $hash ?>';
    function submitPayuForm() {
      if(hash == '') {
        return;
      }
      var payuForm = document.forms.payuForm;
      payuForm.submit();
    }
  </script>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="keywords" content="www.thinkofit.org, think of it, think of it foundation, ngo, teach, volunteer, social work, donate,he help, charity, city, help, ngos, online">
<!-- Bootstrap CSS -->
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
<link href="css/stylesheet_1.css" rel="stylesheet" type="text/css">
<link rel="icon" href="media/icon_toi.png" type="image/x-icon">
<title>Donate</title>
</head>

<body onload="submitPayuForm()">
<!--<?php //include "./navbar_toi.php" ?> -->
<!-----------------------------------------------Header Carousel---------------------------------------->
<header>
  <div id="donate_slider">
    <div id="carouselExampleIndicators" class="carousel slide carousel-fade" data-ride="carousel">
      <div class="carousel-inner" role="listbox"> 
        <!-- Slide One - Set the background image for this slide in the line below -->
        <div class="carousel-item active" style="background-image: url('media/donate_slider1.jpg')"> </div>
        <!-- Slide Two - Set the background image for this slide in the line below -->
        <div class="carousel-item" style="background-image: url('media/donate-slider2.jpg');"> </div>
        <!-- Slide Three - Set the background image for this slide in the line below -->
        <div class="carousel-item" style="background-image: url('media/donate-slider3.jpg')"> </div>
      </div>
      <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev"> <span class="carousel-control-prev-icon" aria-hidden="true"></span> <span class="sr-only">Previous</span> </a> <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next"> <span class="carousel-control-next-icon" aria-hidden="true"></span> <span class="sr-only">Next</span> </a> </div>
  </div>
</header>
<div class="container">
  <div class="row">
    <div id = donate_content class="col-sm" style="padding-right: 20px; margin-top:50px;">
     <h3 style="font-family:Segoe, 'Segoe UI', 'DejaVu Sans', 'Trebuchet MS', Verdana, 'sans-serif'"><i class="fa fa-quote-left"></i> The measure of a life, after all, is not it's duration, but it's donation - Corrie Ten Boom. <i class="fa fa-quote-right"></i></h3>
<!--     <h3>WHAT YOU CAN CHANGE</h3>-->
      <p>The decrepit condition of 80 per cent of government  schools in terms of infrastructure and learning calls for revamping of the conditions for children who do not choose to be born into poverty but are conditioned to bear its constraints. </p>
      <ol>
      	<li>The infrastructure in government schools is in a poor State, 40 percent of schools function without electricity.</li>
      	<li>As many as 31 per cent of the faculty impart education without having degrees themselves.</li>
      	<li>Half of the country’s poverty-stricken can only afford government schools that neglect their needs for a well-rounded educational atmosphere.</li>
      </ol>
      <b><p>But you can turn around the situation by putting in efforts. ‘Think of It’ aims to incorporate a long-term impact hence, your investment – be it,</p>
      <ul>
      	<li>Monetary or</li>
      	<li>by Volunteering in our various programs;</li>
      </ul>
      <p>will ensure that you are leading small but grave steps toward a positive future.</p></b>
      <p>There is no peace in selfish procurement of materialistic endeavors; real peace lies in the selfless acts of kindness. The smile that you manage to put on a face that has been sleeping on an empty stomach but still wants to digest enough learning to stand up on their feet someday is irreplaceable.</p>
      
      <p class="text-center"><b>"What a privilege to be here on the planet to contribute your unique donation to humankind. Each face in the rainbow of colors that populate our world is precious and special" - Morris Dees </b></p>
      <p>Join us and invest your time in something that’s not just worthwhile but also noble.</p>
    </div>
    <div id="donate_form" class="col-sm" style="margin-top: 60px;">
      <?php if($formError) { ?>
  
      <span style="color:red">Please fill all mandatory fields.</span>
    <?php } ?>
      <form action="<?php echo $action; ?>" method="post" name="payuForm" class="needs-validation" novalidate style="background-color: rgba(2,50,145,0.70); padding:25px;">
        <input type="hidden" name="key" value="<?php echo $MERCHANT_KEY; ?>" />
        <input type="hidden" name="hash" value="<?php echo $hash; ?>"/>
        <input type="hidden" name="txnid" value="<?php echo $txnid; ?>" />
        <div class="form-row">
          <div class="col">
            <input type="text" class="form-control" name="firstname" placeholder="First name" pattern="[a-zA-Z]{2,}"   value="<?php echo (empty($posted['firstname'])) ? '' : $posted['firstname']; ?>" required>
            <div class="invalid-feedback"> *Enter a valid first name. </div>
          </div>
          <div class="col">
            <input type="text" class="form-control" placeholder="Last name" pattern="[a-zA-Z]{2,}" required>
            <div class="invalid-feedback"> *Enter a valid last name. </div>
          </div>
        </div>
        <div class="form-row">
          <div class="col">
            <input type="text" name="phone" class="form-control" placeholder="Contact No." pattern="[6789][0-9]{9}" 
            value="<?php echo (empty($posted['phone'])) ? '' : $posted['phone']; ?>" required>
            <div class="invalid-feedback"> *Enter a valid contact no. </div>
          </div>
        </div>
        <div class="form-row">
          <div class="col">
            <input type="email" name="email" class="form-control" placeholder="Email Address" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" value="<?php echo (empty($posted['email'])) ? '' : $posted['email']; ?>" required>
            <div class="invalid-feedback"> *Please provide a vaild email-id. </div>
          </div>
        </div>
        <input type="hidden" name="surl" value="http://localhost/PayUMoney-PHP-Module-master/paymentsuccess.php" size="64" />
        <input type="hidden" name="furl" value="http://localhost/PayUMoney-PHP-Module-master/paymentfailed.php" size="64" />
        <input type="hidden"  name="service_provider" value="payu_paisa" size="64" />
        <input type="hidden" name="curl" value="http//localhost/PayUMoney-PHP-Module-master/failure.php" />
        <input type="hidden" name="udf3" value="<?php echo $veryfy?>" />
        <div class="form-row">
          <div class="col">
            <select class="form-control custom-select"  id="city" required>
              <option value="" selected disabled>Select a city</option>
              <option value="Ahmedabad">Ahmedabad</option>
              <option value="Amravati">Amravati</option>
              <option value="Bangaluru">Bangaluru</option>
              <option value="Bhopal">Bhopal</option>
              <option value="Chandigarh">Chandigarh</option>
              <option value="Chennai">Chennai</option>
              <option value="Dehradun">Dehradun</option>
              <option value="Delhi">Delhi</option>
              <option value="Hyderabad">Hyderabad</option>
              <option value="Indore">Indore</option>
              <option value="Jaipur">Jaipur</option>
              <option value="Kolkata">Kolkata</option>
              <option value="Mumbai">Mumbai</option>
              <option value="Nagpur">Nagpur</option>
              <option value="Nashik">Nashik</option>
              <option value="Pune">Pune</option>
              <option value="Surat">Surat</option>
            </select>
            <input type="hidden" name="city"  id="scity"  value="<?php echo (empty($posted['city'])) ? '' : $posted['city']; ?>" />
            <div class="invalid-feedback"> *Please choose a city. </div>
          </div>
        </div>
        <div class="form-row">
          <div class="col">
            <input type="text" name="udf2" class="form-control" placeholder="Aadhaar No. (XXXX-XXXX-XXXX)" pattern="^[2-9]\d{3}-\d{4}-\d{4}$" value="<?php echo (empty($posted['udf2'])) ? '' : $posted['udf2']; ?>" required>
            <div class="invalid-feedback"> *Please provide correct aadhaar no. </div>
          </div>
        </div>
        <div class="form-row">
          <div class="col">
            <input type="text" name="udf1" class="form-control" placeholder="PAN Card No." pattern="^[A-Z]{5}[0-9]{4}[A-Z]{1}$" value="<?php echo (empty($posted['udf1'])) ? '' : $posted['udf1']; ?>" required>
            <div class="invalid-feedback"> *Please provide correct PAN Card No. </div>
          </div>
        </div>
        <b class="text-light">Amount in Indian Rupees :</b>
        <div class="form-row" style="background-color: rgba(4,33,51,0.60); padding-top:4%; padding-left:3%; border-top-left-radius: 15px; border-top-right-radius: 15px;">
          <div class="col">
            <div class="form-check text-light">
              <input class="form-check-input" type="radio" name="amt" id="amt1" value="1">
              <label class="form-check-label" for="gridRadios1"> 2000 </label>
            </div>
          </div>
          <div class="col">
            <div class="form-check text-light">
              <input class="form-check-input" type="radio" name="amt" id="amt2" value="5000">
              <label class="form-check-label" for="gridRadios1"> 5000 </label>
            </div>
          </div>
          <div class="col">
            <div class="form-check text-light">
              <input class="form-check-input" type="radio" name="amt" id="amt3" value="10000">
              <label class="form-check-label" for="gridRadios1"> 10000 </label>
            </div>
          </div>
        </div>
        <div class="form-row" style="background-color: rgba(4,33,51,0.60); border-bottom-left-radius: 15px; border-bottom-right-radius: 15px;">
          <div class="col">
            <input id="dis_amt" type="number" name="amount" min="1" class="form-control" placeholder="Select/Enter Donation Amount" value="<?php echo (empty($posted['amount'])) ? '' : $posted['amount'] ?>" required>
            <div class="invalid-feedback"> *Please select/enter valid amount. </div>
          </div>
        </div>
        <br>
        <b class="text-light">Where would you like your money to be used :</b>
        <div class="row ml-1">
          <div class="col-sm-4 mb-2">
            <div class="form-check text-light">
              <input class="form-check-input" type="radio" name="project" id="need" value="Where Needed">
              <label class="form-check-label" for="gridRadios1"> Where Needed </label>
            </div>
          </div>
          <div class="col mb-2">
            <div class="form-check text-light">
              <input class="form-check-input" type="radio" name="project" id="ylp" value="Social Responsibility through TOI-YLP">
              <label class="form-check-label" for="gridRadios1"> Social Responsibility through TOI-YLP </label>
            </div>
          </div>
        </div>
        <div class="row  ml-1">
          <div class="col-sm-4 mb-2">
            <div class="form-check text-light">
              <input class="form-check-input" type="radio" name="project" id="r2t_radio" value="Reach To Teach">
              <label class="form-check-label" for="gridRadios1"> Reach To Teach </label>
            </div>
          </div>
          <div class="col mb-2">
            <div class="form-check text-light">
              <input class="form-check-input" type="radio" name="project" id="rad_radio" value="Raise A Dream">
              <label class="form-check-label" for="gridRadios1"> Raise A Dream </label>
            </div>
          </div>
        </div>
        <div class="row  ml-1">
          <div class="col  mb-2">
            <div class="form-check text-light">
              <input class="form-check-input" type="radio" name="project" id="sp" value="Specific Project - Mention">
              <label class="form-check-label mr-3" for="gridRadios1" style="float: left;"> Specific Project - Mention </label>
              <input id="project_name" type="text" class="form-control col-sm-4 col-form-label-sm" placeholder="Project Name" pattern="[a-zA-Z]{2,}" style="display: none;">
            </div>
          </div>
        </div>
        <input type="hidden" name="productinfo"   id="sneed"  value="<?php echo (empty($posted['productinfo'])) ? '' : $posted['productinfo']; ?>">
        <div class="form-row">
          <div class="col">
            <input id="project_id" type="text" class="form-control" placeholder="Project value" style="display: none;" >
            <div class="invalid-feedback"> *Select an option. </div>
          </div>
        </div>
        <small class="form-text" style="color:rgba(255,206,0,1.00);">*We'll need this information to issue you certificate/reciept of donation.</small> <small class="form-text" style="color:rgba(255,206,0,1.00);">*Information would be kept totally confidential and won't be shared under any circumstances.</small> <br>
        <?php if(!$hash) { ?>
        <input class="btn btn-warning btn-block" type="submit" value="Proceed to pay">
         <?php } ?>
      </form>
    </div>
  </div>
</div>
<!-------------------------------------------------------FOOTER---------------------------------------------------->
<!--<?php //include "./footer.php" ?> -->
<!---------------------------------------------------------Script----------------------------------------------------> 
<script src="https://use.edgefonts.net/luckiest-guy.js"></script> 
<script src="https://use.edgefonts.net/muli.js"></script> 
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.0-alpha1/js/bootstrap.bundle.min.js"></script> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script> 
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script> 
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> 
<script>
			// Example starter JavaScript for disabling form submissions if there are invalid fields
			(function() {
			  'use strict';
			  window.addEventListener('load', function() {
			    // Fetch all the forms we want to apply custom Bootstrap validation styles to
			    var forms = document.getElementsByClassName('needs-validation');
			    // Loop over them and prevent submission
			    var validation = Array.prototype.filter.call(forms, function(form) {
			      form.addEventListener('submit', function(event) {
			        if (form.checkValidity() === false) {
			          event.preventDefault();
			          event.stopPropagation();
			        }
			        form.classList.add('was-validated');
			      }, false);
			    });
			  }, false);
			})();
		</script> 
<script>
    $(document).ready(function(){
        $("input[type='radio']").click(function(){
            var radioValue = $("input[name='amt']:checked").val();
            if(radioValue){
                var dis_amt = document.getElementById('dis_amt');
				dis_amt.value = radioValue;
            }
        });
    });
</script> 
<script>
    $(document).ready(function(){
        $("input[type='radio']").click(function(){
            var project_value = $("input[name='project']:checked").val();
			if(project_value){
				var project_id = document.getElementById('project_id');
				project_id.value = project_value;
			}
            if(project_value=="Where Needed"||project_value=="Social Responsibility through TOI-YLP"||project_value=="Reach To Teach"||project_value=="Raise A Dream"){
				var project_name = document.getElementById('project_name');
				project_name.style.display = "none";
				project_name.required = false;
			}
			if(project_value=="Specific Project - Mention"){
				var project_name = document.getElementById('project_name');
				project_name.style.display = "block";
				project_name.required = true;
			}
			
        });
    });

$(document).ready(function() { 
    $('#city').change(function() {
      $('#scity').val($('#city').val());
    });
});

$(document).ready(function() { 
    $('#need').change(function() {
      $('#sneed').val($('#need').val());
    });
});

$(document).ready(function() { 
    $('#ylp').change(function() {
      $('#sneed').val($('#ylp').val());
    });
});

$(document).ready(function() { 
    $('#r2t_radio').change(function() {
      $('#sneed').val($('#r2t_radio').val());
    });
});

$(document).ready(function() { 
    $('#rad_radio').change(function() {
      $('#sneed').val($('#rad_radio').val());
    });
});

$(document).ready(function() { 
    $('#project_name').change(function() {
      $('#sneed').val($('#project_name').val());
    });
});

</script>
</body>
</html>

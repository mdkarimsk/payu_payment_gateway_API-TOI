<?php
$status=$_POST["status"];
$firstname=$_POST["firstname"];
$amount=$_POST["amount"];
$txnid=$_POST["txnid"];
$posted_hash=$_POST["hash"];
$key=$_POST["key"];
$productinfo=$_POST["productinfo"];
$email=$_POST["email"];
$m=$_POST['phone'];
$ver=$_POST['udf3'];
$salt="lPPYFQFEou";
$city=$_POST['city'];
$pan=$_POST['udf1'];
$adhar=$_POST['udf2'];
$bank_ref=$_POST['bank_ref_num'];
$mode=$_POST['bankcode'];
$date=$_POST['addedon'];
//print_r($_POST);

  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "test";
  $conn = mysqli_connect('localhost','u279329961_aditya','^u3[h8sD','u279329961_THINK_OF_IT');

  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }

// Salt should be same Post Request 

If (isset($_POST["additionalCharges"])) {
       $additionalCharges=$_POST["additionalCharges"];
        $retHashSeq = $additionalCharges.'|'.$salt.'|'.$status.'|||||||||||'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;
  } else {
        $retHashSeq = $salt.'|'.$status.'|||||||||||'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;
        $veryfy=strtolower(hash('sha512', $salt));
         }
     $hash = $veryfy;
       if ($hash != $ver) {
         echo "Invalid Transaction. Please try again";
       } else {

            $stmt = $conn->prepare("INSERT INTO donation_toi (name, email, phone, amount, transaction_id,status, project,city,pan,aadhar)  VALUES (?,?, ?, ?, ?, ?, ?, ?,?,?)");
            $stmt->bind_param("ssssssssss",$firstname,$email,$m,$amount,$txnid,$status,$productinfo,$city,$pan,$adhar);
            $stmt->execute();
            $stmt->close();
    $to =$email; 
    $subject = "Payment Details for the Transaction at Think of It Foundation";
    
    $message = " 
      <center><img src='https://www.thinkofit.org/media/verify/removed_bg_logo_aditya.png' width='auto' height='50'></center>
      <h3> Transaction Details</h3>
      <table style='border:1px solid black'>
        <tr colspan='2' style='border:1px solid black;background-color:green;'>
          <td style='border:1px solid black;font-weight:bold;'>Description</td>
          <td style='border:1px solid black;font-weight:bold;'>Value</td>
        </tr>
        <tr colspan='2' style='border:1px solid black'>
          <td style='border:1px solid black'>Name</td>
          <td style='border:1px solid black'>$firstname</td>
        </tr>
        <tr colspan='2' style='border:1px solid black'>
          <td style='border:1px solid black'>Amount</td>
          <td style='border:1px solid black'>$amount</td>
        </tr>
        <tr colspan='2' style='border:1px solid black'>
          <td style='border:1px solid black'>Transaction Status</td>
          <td style='border:1px solid black'>$status</td>
        </tr>
        <tr colspan='2' style='border:1px solid black'>
          <td style='border:1px solid black'>Transaction ID</td>
          <td style='border:1px solid black'>$txnid</td>
        </tr>
        <tr colspan='2' style='border:1px solid black'>
          <td style='border:1px solid black'>Date-time </td>
          <td style='border:1px solid black'>$date</td>
        </tr>
        <tr colspan='2' style='border:1px solid black'>
          <td style='border:1px solid black'>Payment via</td>
          <td style='border:1px solid black'>$mode</td>
        </tr>
        <tr colspan='2' style='border:1px solid black'>
          <td style='border:1px solid black'>Phone No</td>
          <td style='border:1px solid black'>$m</td>
        </tr>
        
      <table><br>
      <p>Think of it Foundation</p>";
    
    $header = "MIME-Version: 1.0" . "\r\n";
    $header .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $header .= 'From: Think of It Foundation <donations@thinkofit.org>' ;
    mail($to,$subject,$message,$header);
  }
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="viewport" content="user-scalable=no, width=device-width, initial-scale=1.0" />
<meta name="apple-mobile-web-app-capable" content="yes" />

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Patua+One&display=swap" rel="stylesheet">
    <title>Success</title>
	
<style type="text/css">


.card-4 {
  box-shadow: 0px 8px 20px 0px rgba(0, 0, 0, 0.15);
  border-radius:50px;  
}

.card-4 .card-body {
  font-family: 'Patua One', cursive;
  padding: 40px 20px;
  padding-bottom: 65px;
  border-radius:50px;
}
img{
  width:500px;
  }

@media (max-width: 767px) {
  .card-4 .card-body {
    padding: 50px 40px;
  }
  img{
  width:300px;
  }
}

h1{
color:#006737;
}
.btn{
border-radius:20px;
box-shadow: 0 5px 5px 0 cyan;
}
</style>
  </head>
  <body>
  <div style="padding-top: 40px;background:#A7CBF4; padding-bottom: 35px;" >
    <div  style="margin: 0 auto; max-width: 680px;" >
       <div class="card card-4" > 
              
           <div class="card-body text-center">
		   
		   <img src="ps.jpg">
		   <h1>Payment &nbsp <?php echo $status; ?></h1>
       <p>Transaction ID : <?php echo $txnid; ?> </p>
      <p>Transaction Amount : <?php echo $amount; ?>&nbsp Rs. </p>
		   <p><i>Thankyou for your payment</i></p>
		   <button type="button" class="btn btn-info">Go to home page</button>
              
	</div>
	</div>
	</div>
	</div>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

    <!-- Option 2: jQuery, Popper.js, and Bootstrap JS
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
    -->
  </body>
</html>
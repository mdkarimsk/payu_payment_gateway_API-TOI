<?php
$status=$_POST["status"];
$firstname=$_POST["firstname"];
$amount=$_POST["amount"];
$txnid=$_POST["txnid"];
$posted_hash=$_POST["hash"];
$key=$_POST["key"];
$productinfo=$_POST["productinfo"];
$email=$_POST["email"];
$m=$_POST['phone'];
$ver=$_POST['udf3'];
$salt="lPPYFQFEou";
$city=$_POST['city'];
$pan=$_POST['udf1'];
$adhar=$_POST['udf2'];
$bank_ref=$_POST['bank_ref_num'];
$mode=$_POST['mode'];
//print_r($_POST);

  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "test";
  $conn = mysqli_connect('localhost','u279329961_aditya','^u3[h8sD','u279329961_THINK_OF_IT');

  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }

// Salt should be same Post Request 

If (isset($_POST["additionalCharges"])) {
       $additionalCharges=$_POST["additionalCharges"];
        $retHashSeq = $additionalCharges.'|'.$salt.'|'.$status.'|||||||||||'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;
  } else {
        $retHashSeq = $salt.'|'.$status.'|||||||||||'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;
        $veryfy=strtolower(hash('sha512', $salt));
         }
     $hash = $veryfy;
       if ($hash != $ver) {
         echo "Invalid Transaction. Please try again";
       } else {

            $stmt = $conn->prepare("INSERT INTO donation_toi (name, email, phone, amount, transaction_id,status, project,city,pan,aadhar)  VALUES (?,?, ?, ?, ?, ?, ?, ?,?,?)");
            $stmt->bind_param("ssssssssss",$firstname,$email,$m,$amount,$txnid,$status,$productinfo,$city,$pan,$adhar);
            $stmt->execute();
            $stmt->close();
    
  }
?>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="viewport" content="user-scalable=no, width=device-width, initial-scale=1.0" />
<meta name="apple-mobile-web-app-capable" content="yes" />

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Patua+One&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <title>Failed</title>
	
<style type="text/css">


.card-4 {
  box-shadow: 0px 8px 20px 0px rgba(0, 0, 0, 0.15);
  border-radius:50px;
  
}

.card-4 .card-body {
  
  font-family: 'Patua One', cursive;
  padding: 40px 20px;
  padding-bottom: 65px;
  border-radius:50px;
}


@media (max-width: 767px) {
  .card-4 .card-body {
    padding: 50px 40px;
  }
 
}
h1{
color:red;
}
.btn{
border-radius:20px;
box-shadow: 0 5px 5px 0 red;
}
</style>
  </head>
  <body>
  <div style="padding-top: 90px;background:#F76959; padding-bottom: 90px;" >
    <div  style="margin: 0 auto; max-width: 680px;" >
       <div class="card card-4 " > 
              
           <div class="card-body text-center">
		   
		    <i class="fas fa-exclamation-triangle"style="font-size:10vw;color:red;"></i>
		   <h1>Payment <?php echo $status; ?></h1>
       <p>Transaction ID : <?php echo $txnid; ?> </p>
		   <p><i>Your payment is failed please contact our customer support.</i></p>
		   <button type="button" class="btn btn-danger">Go to home page</button>
              
	</div>
	</div>
	</div>
	</div>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

    <!-- Option 2: jQuery, Popper.js, and Bootstrap JS
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
    -->
  </body>
</html>